#pragma once
#include "ShapeBuilder.h"
#include "Mesh.h"

class SceneBuilder
{
public:
	static void UBuildScene(vector<GLMesh>& scene);
};
